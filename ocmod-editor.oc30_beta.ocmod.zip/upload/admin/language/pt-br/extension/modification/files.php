<?php
// Heading
$_['heading_title']      = 'Arquivos modificados';

// Text
$_['text_modifications'] = 'Modificações';
$_['text_list']          = 'Listando arquivos modificados';
$_['text_no_results']    = 'Não há arquivos modificados por OCMOD.';
$_['text_file']          = 'Arquivo';
$_['text_modification']  = 'Modificação';
$_['text_version']       = 'Versão';
$_['text_author']        = 'Autor';

// Button
$_['button_return']      = 'Voltar para modificações';