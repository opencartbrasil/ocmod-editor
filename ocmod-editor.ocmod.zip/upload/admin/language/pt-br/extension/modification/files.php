<?php
// Heading
$_['heading_title']      = 'Arquivos modificados';

// Text
$_['text_modifications'] = 'Modificações';
$_['text_list']          = 'Listando arquivos modificados';
$_['text_no_results']    = 'Não há arquivos modificados por OCMOD.';
$_['text_file']          = 'Arquivo';
$_['text_modification']  = 'Modificação';
$_['text_version']       = 'Versão';
$_['text_author']        = 'Autor';
$_['text_ocmod_zip']     = 'Nome do arquivo XML';
$_['no_file_presence']   = 'O arquivo zip não existe';

// Button
$_['button_return']      = 'Voltar';
