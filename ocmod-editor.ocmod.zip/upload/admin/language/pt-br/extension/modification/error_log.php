<?php
// Heading
$_['heading_title']      = 'Log de erros OCMOD';

// Text
$_['text_modifications'] = 'Modificações';
$_['text_success']       = 'O log de erros OCMOD foi apagado!';
$_['text_list']          = 'Listando o log';

// Button
$_['button_return']      = 'Voltar para modificações';

// Error
$_['error_warning']      = 'Atenção: O arquivo %s possui o tamanho de %s!';
$_['error_empty']        = 'Atenção: O arquivo de log de erros OCMOD está vazio!';
$_['error_permission']   = 'Atenção: Você não tem permissão para limpar o log de erros OCMOD!';
