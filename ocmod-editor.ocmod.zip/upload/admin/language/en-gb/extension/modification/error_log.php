<?php
// Heading
$_['heading_title']      = 'OCMOD Error Log';

// Text
$_['text_modifications'] = 'Modifications';
$_['text_success']       = 'Success: You have successfully cleared your OCMOD Error Log!';
$_['text_list']          = 'Errors List';

// Button
$_['button_return']      = 'Return modifications';

// Error
$_['error_warning']      = 'Warning: Your error log file %s is %s!';
$_['error_empty']        = 'Warning: Your error log file empty!';
$_['error_permission']   = 'Warning: You do not have permission to clear error log!';
