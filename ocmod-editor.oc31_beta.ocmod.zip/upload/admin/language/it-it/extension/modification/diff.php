<?php
// Heading
$_['heading_title']      = 'Analisi modificatori';

// Text
$_['text_modifications'] = 'Modificatori';
$_['text_help_diff']     = '<strong>Aiuto:</strong><br>A sinistra il file originale e a destra il file modificato.';

// Button
$_['button_return']      = 'Restituisce i file modificati';

// Error
$_['error_permission']   = 'Attenzione: non sei autorizzato a visualizzare il file modificato!';
$_['error_file']         = 'File non trovato!';