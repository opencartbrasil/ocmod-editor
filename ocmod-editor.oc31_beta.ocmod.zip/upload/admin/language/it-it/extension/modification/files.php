<?php
// Heading
$_['heading_title']      = 'File modificati';

// Text
$_['text_modifications'] = 'Modificatori';
$_['text_list']          = 'Modifiche lista file';
$_['text_no_results']    = 'Nessun file modificato da OCMOD.';
$_['text_file']          = 'File';
$_['text_modification']  = 'Modificatori';
$_['text_version']       = 'Versione';
$_['text_author']        = 'Autore';

// Button
$_['button_return']      = 'Restituisci modifiche';